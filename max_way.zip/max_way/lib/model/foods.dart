class Foods{
  String title;
  String content;
  String imgName;
  String cost;

  Foods({required this.title,
    required this.content,
    required this.imgName,
    required this.cost,
   }
      );
}