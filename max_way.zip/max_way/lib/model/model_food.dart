import 'package:flutter/material.dart';
import 'package:max_way/float.dart';

import 'foods.dart';

class FoodsCategory extends StatefulWidget {
  const FoodsCategory({Key? key}) : super(key: key);

  @override
  State<FoodsCategory> createState() => _FoodsCategoryState();
}

class _FoodsCategoryState extends State<FoodsCategory> {
  static List<Foods> pitsa = [
    Foods(
        title: "Gavaya",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/pitsa.png',
        cost: "45,000 UZS"),
    Foods(
        title: "Mexica",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/mexica.png',
        cost: "64,000 UZS"),
    Foods(
        title: "Hot achchiko",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/pitsa.png',
        cost: "53,000 UZS"),
  ];
  static List<Foods> burger = [
    Foods(
        title: "Cheeseburger",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/burger.png',
        cost: "45,000 UZS"),
    Foods(
        title: "Chiliburger",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/burger.png',
        cost: "64,000 UZS"),
    Foods(
        title: "Hamburger",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/burger.png',
        cost: "53,000 UZS"),
  ];
  static List<Foods> kombo = [
    Foods(
        title: "Kombo-1",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/kombo.png',
        cost: "23,000 UZS"),
    Foods(
        title: "Kombo-2",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/combo2.png',
        cost: "25,000 UZS"),
    Foods(
        title: "Kombo-3",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/kombo.png',
        cost: "30,000 UZS"),
  ];
  static List<Foods> waters = [
    Foods(
        title: "Sprite 1L",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/water.png',
        cost: "6,000 UZS"),
    Foods(
        title: "Coca cola 1,5L",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/cola.png',
        cost: "9,000 UZS"),
    Foods(
        title: "Fanta",
        content:
            "Горячая закуска с митболамииз говядины, томатами,моцареллой и соусом чипотле",
        imgName: 'assets/images/fanta.png',
        cost: "6,000 UZS"),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      const Padding(
        padding: EdgeInsets.only(left: 15.0),
        child: SizedBox(
          width: double.infinity,
          child: Text(
            "Pitsa",
            style: TextStyle(
                fontSize: 32.0,
                fontWeight: FontWeight.w700,
                color: Colors.black,
                fontFamily: 'OpenSans'),
          ),
        ),
      ),
      Container(
        child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (BuildContext context, int index) {
            return pitsaItem(pitsa[index]);
          },
          itemCount: pitsa.length,
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black26,width: 1.0),
            borderRadius: BorderRadius.circular(27.0),
          ),
          child: Padding(
            padding:
            const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Opacity(
                  opacity: 0.5,
                  child: Text(
                      "Ko'proq",
                      style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: "Inter-Medium.ttf"
                      )
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      const Padding(
        padding: EdgeInsets.only(left: 15.0),
        child: SizedBox(
          width: double.infinity,
          child: Text(
            "Burger",
            style: TextStyle(
                fontSize: 32.0,
                fontWeight: FontWeight.w700,
                color: Colors.black,
                fontFamily: 'OpenSans'),
          ),
        ),
      ),
      Container(
        child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (BuildContext context, int index) {
            return pitsaItem(burger[index]);
          },
          itemCount: burger .length,
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black26,width: 1.0),
            borderRadius: BorderRadius.circular(27.0),
          ),
          child: Padding(
            padding:
            const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Opacity(
                  opacity: 0.5,
                  child: Text(
                      "Ko'proq",
                      style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: "Inter-Medium.ttf"
                      )
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      const Padding(
        padding: EdgeInsets.only(left: 15.0),
        child: SizedBox(
          width: double.infinity,
          child: Text(
            "Kombo",
            style: TextStyle(
                fontSize: 32.0,
                fontWeight: FontWeight.w700,
                color: Colors.black,
                fontFamily: 'OpenSans'),
          ),
        ),
      ),
      Container(
        child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (BuildContext context, int index) {
            return pitsaItem(kombo[index]);
          },
          itemCount: kombo.length,
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black26,width: 1.0),
            borderRadius: BorderRadius.circular(27.0),
          ),
          child: Padding(
            padding:
            const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Opacity(
                  opacity: 0.5,
                  child: Text(
                      "Ko'proq",
                      style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: "Inter-Medium.ttf"
                      )
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      const Padding(
        padding: EdgeInsets.only(left: 15.0),
        child: SizedBox(
          width: double.infinity,
          child: Text(
            "Ichimliklar",
            style: TextStyle(
                fontSize: 32.0,
                fontWeight: FontWeight.w700,
                color: Colors.black,
                fontFamily: 'OpenSans'),
          ),
        ),
      ),
      Container(
        child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (BuildContext context, int index) {
            return pitsaItem(waters[index]);
          },
          itemCount: waters.length,
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black26,width: 1.0),
            borderRadius: BorderRadius.circular(27.0),
          ),
          child: Padding(
            padding:
            const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Opacity(
                  opacity: 0.5,
                  child: Text(
                      "Ko'proq",
                      style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: "Inter-Medium.ttf"
                      )
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ]);
  }

  Widget pitsaItem(Foods pitsa, ) {
    int count=0;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
        child: Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 1,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 16.0, right: 10, top: 20, bottom: 20),
                child: Image.asset("${pitsa.imgName}"),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        pitsa.title,
                        style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20,
                            fontFamily: "Inter-Regular.ttf"),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: Opacity(
                          opacity: 0.4,
                          child: Text(
                            pitsa.content,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w500),
                            maxLines: 3,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            pitsa.cost,
                            style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 20,
                                fontFamily: "Inter-Regular.ttf"),
                          ),
                          FloatButtons(),
                        ],
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    ]);
  }

}
