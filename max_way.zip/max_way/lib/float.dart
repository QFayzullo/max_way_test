import 'package:flutter/material.dart';
import 'package:badges/badges.dart' as badges;
class FloatButtons extends StatefulWidget {
   const FloatButtons({Key? key}) : super(key: key);

  @override
  State<FloatButtons> createState() => _FloatButtonsState();
}

class _FloatButtonsState extends State<FloatButtons> {
  int count=0;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FloatingActionButton(
          backgroundColor: Colors.amber,
          onPressed: () {
            setState(() {
              count++;
            });
          },child: Icon(Icons.add),
        ),
      ),
    );
  }
  Widget floatOrd(){
    return Container(
      child: badges.Badge(
        badgeContent: Text(count.toString(),
          style: TextStyle(fontSize: 10.0),
        ),
        child: Icon(Icons.shopping_bag,size: 25,color: Colors.amber,),
      ),
    );
  }
}
