import 'package:flutter/material.dart';
import 'package:max_way/appbar/second_appbar_item.dart';
import 'package:max_way/model/pop.dart';
import 'package:max_way/color/colors.dart';
import 'package:max_way/model/model_food.dart';
import '../appbar/appbar.dart';
import '../model/items.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          title: const AppBarSourse(),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Column(
                children: [
                  Image.asset('assets/images/main.png'),
                ],
              ),
              const Text(
                "Siz izlagan mazzali ta'mlar",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 45.0,
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                    fontFamily: 'OpenSans'),
              ),
              const Popular(),
              const SecondAppBarItem(),
              const FoodsCategory(),
              Stack(children: [
                Padding(
                  padding: const EdgeInsets.only(top: 180.0),
                  child: Container(
                    width: double.infinity,
                    height: 685.0,
                    color: AppColors.max_color,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 82.0),
                          child: Image.asset("assets/images/doppi.png"),
                        ),
                        const Text(
                          "Mobil ilovamiz orqali buyurtma berish yanada osonroq",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 36.0, color: Colors.white),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 15.0, right: 15, top: 48),
                          child: Container(
                            decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.white, width: 0.5),
                              borderRadius: BorderRadius.circular(27.0),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 12, horizontal: 15),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Image.asset("assets/images/google.png"),
                                  const VerticalDivider(width: 16),
                                  const Text("Google play",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20.0,
                                          fontFamily: "Inter-Medium.ttf")),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 15.0, vertical: 12),
                          child: Container(
                            decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.white, width: 0.5),
                              borderRadius: BorderRadius.circular(27.0),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 12, horizontal: 15),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Image.asset("assets/images/apple.png"),
                                  const VerticalDivider(width: 16),
                                  const Text("App Store",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20.0,
                                          fontFamily: "Inter-Medium.ttf")),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 60.0),
                  child: Center(child: Image.asset("assets/images/phone.png")),
                ),
              ]
              ),


              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Divider(
                  thickness: 1,
                  color: Colors.black26,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      "Asosiy",
                      style: TextStyle(fontSize: 18.0, fontFamily: "Inter-Medium.ttf"),
                    ),
                    Image(
                      image: AssetImage(
                        "assets/images/down.png",
                      ),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Divider(
                  thickness: 1,
                  color: Colors.black26,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      "Qo'shimcha",
                      style: TextStyle(fontSize: 18.0, fontFamily: "Inter-Medium.ttf"),
                    ),
                    Image(
                      image: AssetImage(
                        "assets/images/down.png",
                      ),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Divider(
                  thickness: 1,
                  color: Colors.black26,
                ),
              ),
              const SizedBox(width: 20.0),
              const Text(
                "(+998 71) 200-54-00",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 25.0, color: Colors.black87, fontWeight: FontWeight.normal),
              ),
              const SizedBox(height: 30.0),
              const Text(
                "100011, Toshkent sh. Shayxontohur tumani,Zarqaynar ko’chasi, 3B-uy",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16.0, color: Colors.black54, fontWeight: FontWeight.normal),
              ),
              const SizedBox(width: 20.0,),
              const Items(),
              const SizedBox(width: 20.0,),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Divider(
                  thickness: 1,
                  color: Colors.black26,
                ),
              ),
              const SizedBox(height: 30.0),
              const Text(
                "© Maxway, 2020",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14.0, color: Colors.black54, fontWeight: FontWeight.normal),
              ),
              const SizedBox(width: 20.0),
            ],
          ),
        ),
      ),
    );
  }
}
