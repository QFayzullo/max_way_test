import 'package:flutter/material.dart';
abstract class AppColors{
  static const Color blackFood=Color(0xFF222124);
  static const Color max_color=Color(0xFF800A7A);
}