package com.example.max_way

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
